package org.sopt.seminar4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Seminar4Application {

    public static void main(String[] args) {
        SpringApplication.run(Seminar4Application.class, args);
    }
}
