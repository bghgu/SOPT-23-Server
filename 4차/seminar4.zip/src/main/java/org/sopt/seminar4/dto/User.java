package org.sopt.seminar4.dto;

import lombok.Data;

/**
 * Created by ds on 2018-11-05.
 */

@Data
public class User {
    private int userIdx;
    private String name;
    private String part;
}
